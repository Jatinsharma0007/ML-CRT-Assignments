x = 3.5
x += 10
print(x)